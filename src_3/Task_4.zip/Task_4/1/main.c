#include <stdio.h>
#include <time.h>

struct timespec
{
       time_t tv_sec; //Секунды
       long tv_nsec;  //Наносекунды
};

int nanosleep(const struct timespec *req, struct timespec *rem);

int main (void)
{    
   struct timespec tw = {1,0};

   struct timespec tr;

   nanosleep(&tw, &tr);

   printf("Done");
   
   return 0;
}
