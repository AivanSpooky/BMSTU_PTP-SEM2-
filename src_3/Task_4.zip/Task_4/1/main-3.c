//#define _POSIX_C_SOURCE 199309L

#include <time.h>
#include <stdio.h>
#include <unistd.h>

#define OK 0

struct timespec
{
   time_t tv_sec;
   long tv_nsec;
};

int nanosleep(const struct timespec *req, struct timespec *rem);

// Замерительный метод - clock()
int main (void)
{
   // // Файл для сохранения замера времени
   // FILE *file;
   // size_t test_n;
   // scanf("%zu", &test_n);

   // file = fopen("./dataset/t_1_.txt", "w");

   struct timespec tw = {0,10*1e+6};
   struct timespec tr;

   double time_spent = 0;

   //unsigned long long beg, end;

   //printf("Программа останавливается на 1 секунду\nПроизводится замер времени выполнения:\n\n");
   //printf("BEGIN:\n");

   clock_t begin = clock();
   //printf("seconds : %ld\nmicro seconds : %ld\n\n", current_time.tv_sec, current_time.tv_usec);
   //beg = start.tv_sec * 1000ULL + start.tv_nsec / 1000ULL;
   nanosleep(&tw, &tr);
   clock_t end = clock();
   //end = ending.tv_sec * 1000ULL + ending.tv_nsec / 1000ULL;
   //printf("seconds : %ld\nmicro seconds : %ld\n\n", current_time.tv_sec, current_time.tv_usec);
   time_spent += (double)(end - begin) * 1000ULL / CLOCKS_PER_SEC;
   //printf("END:\n");
   printf("%f\n", time_spent);
   //printf("Done!\n");
   // fprintf(file, "%llu", end-beg);
   // fclose(file);

   return OK;
}
