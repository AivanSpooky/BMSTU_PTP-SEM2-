#!/bin/bash

cd ./func_tests/scripts/ || exit 1
./func_tests.sh
cd ../../
