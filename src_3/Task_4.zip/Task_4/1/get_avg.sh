#!/bin/bash

if [ -f "./dataset/t_'$1'_1.txt" ]
then
    summ=0
    n=0
    for (( i=1; i <= 20; i++ ))
    do
        while read -r n; do
            summ=$(( summ + n ))
        done < "./dataset/t_'$1'_'$i'.txt"
    done
    avg=$(( summ / 20 ))
    rm -f ./avg/t_"$1".txt
    echo "$avg" >> ./avg/t_"$1".txt
else
    echo "please, enter programm key!"
fi
