#!/bin/bash

python3 ./make_preproc.py
