#ifndef __MATRIX_H__
#define __MATRIX_H__

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>

// Инициализировать матрицу произвольными значениями
void init(int a[][NMAX], size_t size);

#endif